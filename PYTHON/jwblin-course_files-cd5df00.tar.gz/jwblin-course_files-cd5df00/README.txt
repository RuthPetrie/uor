README FILE


These files accompany the book "A Hands-On Introduction to Using Python
in the Atmospheric and Oceanic Sciences," by Johnny Wei-Bing Lin (2012).
Please visit the book's web page:

http://www.johnny-lin.com/pyintro/

for information about obtaining a copy of the book.  Code licensing
information is given in the individual Python code files.  This README
file is covered by the same license as the book.
